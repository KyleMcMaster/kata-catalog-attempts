﻿using System;

namespace Kata.Starter
{
    public class Game
    {
        public int[] DiceValues { get; protected set; }
        private Random Random { get; }

        public Game()
        {
            DiceValues = new int[6] { 0, 0, 0, 0, 0, 0 };

            Random = new Random();
        }

        public void Roll()
        {
            for (int i = 0; i < 6; i++)
            {
                int dieValue = Random.Next(0, 6);
                DiceValues[dieValue] = DiceValues[dieValue] + 1;
            }
        }

        public int Score(int[] testdata = null)
        {
            if (testdata != null)
            {
                DiceValues = testdata;
            }

            int score = 0;
            int index = -1;
            int numberOfOccurences = 6;

            while (index == -1 && numberOfOccurences >= 3)
            {
                index = Array.IndexOf(DiceValues, numberOfOccurences);
                numberOfOccurences--;
            }

            switch (index)
            {
                case 0:
                    score += 1000;
                    break;
                case 2:
                    score += 300;
                    break;
                default:
                    break;
            }

            if (DiceValues[0] % 3 == 1)
            {
                score += 100;
            }

            if (DiceValues[4] % 3 == 1)
            {
                score += 50;
            }

            return score;
        }
    }
}
