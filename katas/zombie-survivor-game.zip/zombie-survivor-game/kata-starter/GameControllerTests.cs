﻿using Xunit;

namespace Kata.Starter
{
    public class GameControllerTests
    {
        private GameController GameController = new GameController();

        //[Fact]
        //public void Survivors_Start_With_The_Ability_To_Perform_Three_Actions_Per_Turn()
        //{
        //    GameController.
        //}
    }
}
