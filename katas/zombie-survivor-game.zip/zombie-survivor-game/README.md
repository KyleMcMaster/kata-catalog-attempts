# kata-starter
Kata template for C# .Net Core 3.0 to promote TDD exercises.

## Packages
- AutoFixture.AutoNSubstitute
- AutoFixture.Xunit2
- FluentAssertions
- xunit